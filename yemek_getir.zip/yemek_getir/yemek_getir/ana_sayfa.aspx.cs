﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace yemek_getir
{
    public partial class ana_sayfa : System.Web.UI.Page
    {
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
           
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("select * from urun_getir", con);
                SqlCommand cmd2 = new SqlCommand("select distinct kategori from kategori", con);
                con.Open();
                DataList1.DataSource = cmd.ExecuteReader();
                DataList1.DataBind();
                Repeater1.DataSource = cmd2.ExecuteReader();
                Repeater1.DataBind();


            }
        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            Response.Redirect("urunler.aspx?id=" + e.CommandArgument.ToString());
        }
        protected void sepet(object sender, EventArgs e)
        {
            
        }
        protected void ekonomik_Click(object sender, EventArgs e)
        {
            Response.Redirect("uclu_firsat.aspx?id=" + ekonomik.CommandArgument.ToString());
            
        }
        protected void encok_siparis_edilen_Click(object sender, EventArgs e)
        {
            Response.Redirect("uclu_firsat.aspx?id=" + encok_siparis_edilen.CommandArgument.ToString());

        }
        protected void encok_favori_Click(object sender, EventArgs e)
        {
            Response.Redirect("uclu_firsat.aspx?id=" + encok_favori.CommandArgument.ToString());

        }
        protected void komagene_Click(object sender, EventArgs e)
        {
            Response.Redirect("urunler.aspx?id=" + komagene.CommandArgument.ToString());

        }
        protected void cikolata_evim_Click(object sender, EventArgs e)
        {
            Response.Redirect("urunler.aspx?id=" + cikolata_evim.CommandArgument.ToString());

        }
        protected void bestof_(object sender, EventArgs e)
        {
            id = Convert.ToInt32(best_of.CommandArgument);
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                if (Session["kullanici_adi"] != null)
                {
                    con.Open();
                    int[] urunler = { 9, 17 };
                    for(int i = 0; i < 2; i++)
                    {
                        SqlCommand cmd = new SqlCommand("sepete_ekle", con);
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd.Parameters.AddWithValue("@id", urunler[i]);

                        cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                        cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();
                        string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();

                        if (mesaj != " ")
                        {
                            string script2 = "alert(\"'" + mesaj + "'\");";
                            ScriptManager.RegisterStartupScript(this, GetType(),
                                                  "ServerControlScript", script2, true);

                        }
                        //else
                        //{

                        //    Response.Redirect("sepet.aspx");
                        //}
                    }
                    Response.Redirect("sepet.aspx");
                }
                else
                {
                    string script2 = "alert(\"'Lütfen alışverişten önce hesabınıza giriş yapınız.'\");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script2, true);
                }


            }


        }
        protected void pasaport_(object sender, EventArgs e)
        {
            id = Convert.ToInt32(pasaport_pizza.CommandArgument);
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                if (Session["kullanici_adi"] != null)
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("sepete_ekle", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.Parameters.AddWithValue("@id", 83);

                    cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                    cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();

                    if (mesaj != " ")
                    {
                        string script2 = "alert(\"'" + mesaj + "'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);

                    }
                    else
                    {

                        Response.Redirect("sepet.aspx");
                    }
                }
                else
                {
                    string script2 = "alert(\"'Lütfen alışverişten önce hesabınıza giriş yapınız.'\");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script2, true);
                }


            }

        }
    }
}