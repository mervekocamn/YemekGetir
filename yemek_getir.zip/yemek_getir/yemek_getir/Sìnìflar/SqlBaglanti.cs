﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace yemek_getir.Sınıflar
{
    public class SqlBaglanti
    {

        public static SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True");
            
        public static void baglanti_kontrol()
        {
            if (con.State == System.Data.ConnectionState.Closed)
            {
                con.Open();

            }
            else { }
        }

    }


}