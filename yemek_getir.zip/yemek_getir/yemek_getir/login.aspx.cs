﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace yemek_getir
{
    
    public partial class login : System.Web.UI.Page
    {
        string mesaj_ ="Girilen mail veya şifre hatalı";
        int count = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            Master.buton();
        }

        protected void btn_giris_Click(object sender, EventArgs e)
        {
            SqlConnection sql_ = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True");
            sql_.Open();
            string query = "select count(mail) from kullanici_login where mail=@mail and sifre=@sifre";
            SqlCommand sqlcmd = new SqlCommand(query, sql_);
            sqlcmd.Parameters.AddWithValue("@mail", user.Text);
            sqlcmd.Parameters.AddWithValue("@sifre", sifre.Text);
            count = Convert.ToInt32(sqlcmd.ExecuteScalar());
   
            if (count != 1)
            {
                string script2 = "alert(\"'" + mesaj_ + "'\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script2, true);
                
               

            }
            else
            {
                Session["kullanici_adi"] = user.Text;
                Response.Redirect("ana_sayfa.aspx?Ad=" + user.Text);
                

            }
            sql_.Close();
        }
        protected void forget_sifre(object sender, EventArgs e)
        {
            Response.Redirect("forgetpassword.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }
    }
}