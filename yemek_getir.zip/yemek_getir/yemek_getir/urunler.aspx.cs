﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace yemek_getir
{

    public partial class urunler : System.Web.UI.Page
    {
        string rest_id;
        int id;
        public int MyClass()
        {
            rest_id = Request.QueryString["id"];
            return Convert.ToInt32(rest_id);
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            

            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("select * from urun_getir where res_id=@rest_id", con);

                cmd.Parameters.AddWithValue("@rest_id", MyClass());
                con.Open();
                DataList1.DataSource = cmd.ExecuteReader();
                DataList1.DataBind();

            }
            using (SqlConnection con2 = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
          

                SqlCommand cmd2 = new SqlCommand("select * from yorum_getir where res_id=@rest_id", con2);
                cmd2.Parameters.AddWithValue("@rest_id", MyClass());
                con2.Open();
                Repeater1.DataSource = cmd2.ExecuteReader();
                Repeater1.DataBind();
               

            }
            using (SqlConnection con2 = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {


                SqlCommand cmd2 = new SqlCommand("select distinct kategori from kategori where id=@id", con2);
                cmd2.Parameters.AddWithValue("@id", MyClass());
                con2.Open();
                Repeater2.DataSource = cmd2.ExecuteReader();
                Repeater2.DataBind();


            }

        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "sepete_ekle")
            {
                id = Convert.ToInt32(e.CommandArgument);
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    if(Session["kullanici_adi"]!= null)
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("sepete_ekle", con);
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd.Parameters.AddWithValue("@id", id);
                        
                        cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                        cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();
                        string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();

                        if (mesaj != " ")
                        {
                            string script2 = "alert(\"'" + mesaj + "'\");";
                            ScriptManager.RegisterStartupScript(this, GetType(),
                                                  "ServerControlScript", script2, true);
                            
                        }
                        else
                        {

                            Response.Redirect("sepet.aspx");
                        }
                    }
                    else
                    {
                        string script2 = "alert(\"'Lütfen alışverişten önce hesabınıza giriş yapınız.'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);
                    }
                    
                    
                }
            }
            if (e.CommandName == "favori_ekle")
            {
                id = Convert.ToInt32(e.CommandArgument);
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    if (Session["kullanici_adi"] != null)
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("favori_ekle", con);
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@urun_id", id);
                        cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                        cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();
                        string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();
                        string script2 = "alert(\"'" + mesaj + "'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);

                    }
                    else
                    {
                        string script2 = "alert(\"'Lütfen önce hesabınıza giriş yapınız.'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);
                    }


                }
            }

        }
        protected void Ekle(object sender, EventArgs e)
        {

        }
        protected void artan_filtre(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("select * from urun_getir where res_id=@rest_id order by fiyat", con);

                cmd.Parameters.AddWithValue("@rest_id", MyClass());
                con.Open();
                DataList1.DataSource = cmd.ExecuteReader();
                DataList1.DataBind();

            }
        }
        protected void azalan_filtre(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("select * from urun_getir where res_id=@rest_id order by  fiyat desc", con);

                cmd.Parameters.AddWithValue("@rest_id", MyClass());
                con.Open();
                DataList1.DataSource = cmd.ExecuteReader();
                DataList1.DataBind();

            }
        }
        protected void varsayılan_filtre(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("select * from urun_getir where res_id=@rest_id", con);

                cmd.Parameters.AddWithValue("@rest_id", MyClass());
                con.Open();
                DataList1.DataSource = cmd.ExecuteReader();
                DataList1.DataBind();

            }
        }
    }
}