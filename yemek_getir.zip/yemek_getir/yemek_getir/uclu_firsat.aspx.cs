﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace yemek_getir
{
    public partial class uclu_firsat : System.Web.UI.Page
    {
        public int MyClass()
        {
            string rest_id = Request.QueryString["id"];
            return Convert.ToInt32(rest_id);
        }
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (MyClass() == 3)
            {
                baslik.InnerText = "Ekonomik ve Doyurucu";
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("select top 15 * from uclu_firsat_ekonomik order by fiyat_", con);
                    DataList1.DataSource = cmd.ExecuteReader();
                    DataList1.DataBind();

                }
            }
            else if (MyClass() == 2)
            {
                baslik.InnerText = "En Çok Siparis Edilen";
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("select top 15 * from ençok_siparis_getir_2 order by siparis_sayisi desc ", con);
                    DataList1.DataSource = cmd.ExecuteReader();
                    DataList1.DataBind();

                }
            }
            else if (MyClass() == 1)
            {
                baslik.InnerText = "En Çok Favorilere Eklenen";
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("select top 15 * from ençok_favori_getir_2 order by favori_sayisi desc ", con);
                    DataList1.DataSource = cmd.ExecuteReader();
                    DataList1.DataBind();

                }
            }

        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            

            if (e.CommandName == "menu")
            {
                Response.Redirect("urunler.aspx?id=" + e.CommandArgument.ToString());
            }
            else if (e.CommandName == "sepete_ekle")
            {

                id = Convert.ToInt32(e.CommandArgument);
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    if (Session["kullanici_adi"] != null)
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("sepete_ekle", con);
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd.Parameters.AddWithValue("@id", id);

                        cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                        cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();
                        string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();

                        if (mesaj != " ")
                        {
                            string script2 = "alert(\"'" + mesaj + "'\");";
                            ScriptManager.RegisterStartupScript(this, GetType(),
                                                  "ServerControlScript", script2, true);

                        }
                        else
                        {

                            Response.Redirect("sepet.aspx");
                        }
                    }
                    else
                    {
                        string script2 = "alert(\"'Lütfen alışverişten önce hesabınıza giriş yapınız.'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);
                    }


                }
            }
            else if (e.CommandName == "favori_ekle")
            {
                
                id = Convert.ToInt32(e.CommandArgument);
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    if (Session["kullanici_adi"] != null)
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("favori_ekle", con);
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@urun_id", id);
                        cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                        cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();
                        string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();
                        string script2 = "alert(\"'" + mesaj + "'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);

                    }
                    else
                    {
                        string script2 = "alert(\"'Lütfen önce hesabınıza giriş yapınız.'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);
                    }


                }
                
            }

        }

        protected void DataList1_ItemCreated(object sender, DataListItemEventArgs e)
        {
          
        }
    }
}