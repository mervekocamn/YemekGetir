﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Net.Mime.MediaTypeNames;

namespace yemek_getir
{
    public partial class restorantlar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("rest_getir", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                DataList1.DataSource = cmd.ExecuteReader();
                DataList1.DataBind();

            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {

                Response.Redirect("urunler.aspx?id=" + e.CommandArgument.ToString());

            
        }
    }
}