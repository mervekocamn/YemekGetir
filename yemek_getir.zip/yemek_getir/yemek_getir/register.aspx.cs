﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_getir.Sınıflar;
using System.Windows.Forms;

namespace yemek_getir
{
    public partial class register : System.Web.UI.Page
    {

        string mesaj = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (Page.IsPostBack == false)
            {
               

            }
            else
            {

            }

        }



        protected void btn_kayit_Click(object sender, EventArgs e)
        {

            if (txt_userneme_surname.Text == "" || txt_adres.Text == "" || txt_telno.Text == "" || txt_email.Text == "" || txt_dogum_tarihi.Text == "" || txt_sifre.Text == "" || txt_sifre_tkr.Text == "")
            {

                string script = "alert(\"Lütfen tüm alanları doldurunuz\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);
            }
            else
            {
                SqlConnection con_ = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True");
                Label1.ForeColor = System.Drawing.Color.Red;
                con_.Open();
                SqlCommand komut1 = new SqlCommand("login_ekle", con_);
                komut1.CommandType = System.Data.CommandType.StoredProcedure;


                if (txt_sifre.Text == txt_sifre_tkr.Text)
                {

                    komut1.Parameters.AddWithValue("@isim", txt_userneme_surname.Text.ToString());
                    komut1.Parameters.AddWithValue("@adres", txt_adres.Text);
                    komut1.Parameters.AddWithValue("@tel_no", txt_telno.Text);
                    komut1.Parameters.AddWithValue("@mail", txt_email.Text);
                    komut1.Parameters.AddWithValue("@dogum_tarihi", txt_dogum_tarihi.Text);
                    komut1.Parameters.AddWithValue("@sifre", txt_sifre.Text);
                    komut1.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                    komut1.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                    komut1.ExecuteNonQuery();
                    mesaj = (komut1.Parameters["@mesaj"].Value).ToString();

                    if (mesaj != " ")
                    {
                        if (mesaj.Length > 40)
                        {
                            Response.Write("<script>alert('" + mesaj + "');window.location = 'register.aspx' ; </script>");
                        }
                        else
                        {
                            string script2 = "alert(\"'" + mesaj + "'\");";
                            ScriptManager.RegisterStartupScript(this, GetType(),
                                                  "ServerControlScript", script2, true);
                        }
                        
                        
                    }
                    else
                    {
                        Response.Redirect("login.aspx");
                    }
                }

                else
                {
                    Label2.Text = "Yanlış şifre girişi.";
                    Label2.ForeColor = System.Drawing.Color.Red;

                    txt_sifre.Text = string.Empty;
                    txt_sifre_tkr.Text = string.Empty;
                }
                con_.Close();
            }
        }
        
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }


}
