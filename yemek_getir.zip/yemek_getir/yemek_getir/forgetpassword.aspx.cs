﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace yemek_getir
{
    public partial class forgetpassword : System.Web.UI.Page
    {

        string mesaj;
        SqlConnection sql_ = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_forget_Click(object sender, EventArgs e)
        {
            sql_.Open();
            SqlCommand komut1 = new SqlCommand("sifremi_unuttum", sql_);
            komut1.CommandType = System.Data.CommandType.StoredProcedure;
            if (sifre.Text == sifretekrar.Text)
            {
                komut1.Parameters.AddWithValue("@mail", email.Text);
                komut1.Parameters.AddWithValue("@sifre", sifre.Text);
                komut1.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                komut1.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                komut1.ExecuteNonQuery();
                mesaj = (komut1.Parameters["@mesaj"].Value).ToString();
                if (mesaj != " ")
                {

                    string script2 = "alert(\"'" + mesaj + "'\");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script2, true);
                }
                else
                {
                    string mesaj_ = "Şifre başarıyla değiştirildi.";
                    Response.Write("<script>alert('" + mesaj_ + "');window.location = 'login.aspx' ; </script>"); //works great

                    
                }

            }

            else
            {
                Label1.Text = "Şifreniz ilk şifre ile aynı değil.";
                Label1.ForeColor = System.Drawing.Color.Red;
            }
            sql_.Close();
        }
    }
}