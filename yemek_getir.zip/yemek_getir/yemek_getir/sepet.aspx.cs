﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;

namespace yemek_getir
{
    public partial class sepet : System.Web.UI.Page
    {
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                
            }
            
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("select * from sepet_tablo where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                DataList1.DataSource = cmd.ExecuteReader();
                DataList1.DataBind();

            }
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("select dbo.sepet_son_tutar_guncelle(son_tutar,@kullanici_adi) as son_tutar from sepet_son_tutar_getir  where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);

                con.Open();
                cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                DataList2.DataSource = cmd.ExecuteReader();
                DataList2.DataBind();
                
                
            }
            if (DataList1.Items.Count == 0)
            {
                son_tutar.Visible = false;
                DataList2.Visible = false;
                LinkButton5.Visible = false;

            }
            else
            {
                son_tutar.Visible = true;
                DataList2.Visible = true;
                LinkButton5.Visible = true;
            }
        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName=="sil")
            {
                
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    id = Convert.ToInt32(e.CommandArgument);
                    con.Open();
                    SqlCommand cmd = new SqlCommand("urun_sil", con);
                    SqlCommand cmd2 = new SqlCommand("select * from sepet_tablo where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.ExecuteNonQuery();
                    cmd2.ExecuteNonQuery();
                    DataList1.DataSource = cmd2.ExecuteReader();
                    DataList1.DataBind();
                    Response.Redirect("sepet.aspx");
                }
            }
            if (e.CommandName == "arti")
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("urun_ekle", con); 
                    SqlCommand cmd2 = new SqlCommand("select * from sepet_tablo where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.ExecuteNonQuery();
                    cmd2.ExecuteNonQuery();
                    DataList1.DataSource = cmd2.ExecuteReader();
                    DataList1.DataBind();
                    Response.Redirect("sepet.aspx");
                }
            }
            if (e.CommandName == "eksi")
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("urun_cikar", con);
                    SqlCommand cmd2 = new SqlCommand("select * from sepet_tablo where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.ExecuteNonQuery();
                    cmd2.ExecuteNonQuery();
                    DataList1.DataSource = cmd2.ExecuteReader();
                    DataList1.DataBind();
                    Response.Redirect("sepet.aspx");
                }
            }
            if (e.CommandName == "restorant")
            {
                Response.Redirect("urunler.aspx?id=" + e.CommandArgument.ToString());
            }

        }

        protected void sepeti_onayla(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("sepet_min_tutar_kontrol", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                cmd.Parameters.Add("@res_id", SqlDbType.Int);
                cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                cmd.Parameters["@res_id"].Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();
                string id= (cmd.Parameters["@res_id"].Value).ToString();
                if (mesaj != " ")
                {
                    string script2 = "alert(\"'" + mesaj + "'\");";
                    Response.Write("<script>alert('" + mesaj + "');window.location = 'urunler.aspx?id="+id+"' ; </script>"); //works great

                }
                else
                {
                    Response.Redirect("siparis.aspx");
                }
            }
            
        }
        
    }
}