﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace yemek_getir
{
    public partial class siparis : System.Web.UI.Page
    {
        string odeme_sekli;
        string adres;
        string kupon;
        bool kart_kaydet;
        protected void Page_Load(object sender, EventArgs e)
        {
            DropDownList1.Visible = false;
            drop_baslik.Visible = false;
            kart_bilgi.Visible = false;
            if (RadioButton1.Checked)
            {
                DropDownList1.Visible = false;
                drop_baslik.Visible = false;
                kart_bilgi.Visible = false;
                odeme_sekli = "kapıda";
            }
            if (RadioButton2.Checked)
            {
                DropDownList1.Visible = true;
                drop_baslik.Visible = true;
                kart_bilgi.Visible = true;
                odeme_sekli = "online";
            }
            if (DropDownList1.SelectedValue == "0" || RadioButton1.Checked)
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd2 = new SqlCommand("select dbo.sepet_son_tutar_guncelle(son_tutar,@kullanici_adi) as son_tutar from sepet_son_tutar_getir where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    SqlDataReader dr = cmd2.ExecuteReader();
                    if (dr.Read())
                    {
                        siparis_tutar.InnerText = dr["son_tutar"].ToString();
                        dr.Close();
                        con.Close();
                    }
                }
            }

            else if (RadioButton2.Checked || DropDownList1.SelectedValue != "0")
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd2 = new SqlCommand("select * from sepet_son_tutar_getir where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    SqlDataReader dr = cmd2.ExecuteReader();
                    if (dr.Read())
                    {
                        siparis_tutar.InnerText = dr["son_tutar"].ToString();
                        dr.Close();
                        con.Close();
                    }
                }
            }
            else if(DropDownList1.SelectedValue != "0")
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd2 = new SqlCommand("select dbo.siparis_sayfasinda_kupon(@son_tutar,@kupon_id)", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@son_tutar", Convert.ToInt64(siparis_tutar.InnerText));
                    cmd2.Parameters.AddWithValue("@kupon_id", Convert.ToInt64(DropDownList1.SelectedValue));
                    SqlDataReader dr = cmd2.ExecuteReader();
                    if (dr.Read())
                    {
                        siparis_tutar.InnerText = dr["son_tutar"].ToString();
                        dr.Close();
                        con.Close();
                    }
                }
            }
            if (!Page.IsPostBack)
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("dogum_gunu_kuponu", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.ExecuteNonQuery();
                }
                RadioButton1.Checked = true;
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd2 = new SqlCommand("select * from adres where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    SqlDataAdapter da = new SqlDataAdapter(cmd2);

                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    DropDownList2.DataValueField = "adres";

                    DropDownList2.DataSource = dt;
                    DropDownList2.DataBind();
                }
                adres = DropDownList2.SelectedItem.Value;

                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {

                    SqlCommand cmd = new SqlCommand("select * from kupon_goster where isim=@isim", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@isim", Session["kullanici_adi"]);
                    SqlDataAdapter da2 = new SqlDataAdapter(cmd);

                    DataTable dt2 = new DataTable();
                    da2.Fill(dt2);

                    DropDownList1.DataValueField = "id";
                    DropDownList1.DataTextField = "kupon_ismi";
                    DropDownList1.SelectedValue = "0";
                    DropDownList1.DataSource = dt2;
                    DropDownList1.DataBind();
                }
                
                if (DropDownList1.SelectedValue == "0" || RadioButton1.Checked )
                {
                    using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                    {
                        SqlCommand cmd2 = new SqlCommand("select dbo.sepet_son_tutar_guncelle(son_tutar,@kullanici_adi) as son_tutar from sepet_son_tutar_getir where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                        con.Open();
                        cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        SqlDataReader dr = cmd2.ExecuteReader();
                        if (dr.Read())
                        {
                            siparis_tutar.InnerText = dr["son_tutar"].ToString();
                            dr.Close();
                            con.Close();
                        }
                    }
                }
                
                else if(RadioButton2.Checked || DropDownList1.SelectedValue != "0")
                {
                    using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                    {
                        SqlCommand cmd2 = new SqlCommand("select * from sepet_son_tutar_getir where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                        con.Open();
                        cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        SqlDataReader dr = cmd2.ExecuteReader();
                        if (dr.Read())
                        {
                            siparis_tutar.InnerText = dr["son_tutar"].ToString();
                            dr.Close();
                            con.Close();
                        }
                    }
                }
                else if (DropDownList1.SelectedValue != "0")
                {
                    using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                    {
                        SqlCommand cmd2 = new SqlCommand("select dbo.siparis_sayfasinda_kupon(@son_tutar,@kupon_id)", con);
                        con.Open();
                        cmd2.Parameters.AddWithValue("@son_tutar", Convert.ToInt64(siparis_tutar.InnerText));
                        cmd2.Parameters.AddWithValue("@kupon_id", Convert.ToInt64(DropDownList1.SelectedValue));
                        SqlDataReader dr = cmd2.ExecuteReader();
                        if (dr.Read())
                        {
                            siparis_tutar.InnerText = dr["son_tutar"].ToString();
                            dr.Close();
                            con.Close();
                        }
                    }
                }




            }
        }
        protected void siparis_ver(object sender, EventArgs e)
        {
            if (odeme_sekli == "kapıda")
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("siparis_ver", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.Parameters.AddWithValue("@mesaj", TextBox2.Text);
                    cmd.Parameters.AddWithValue("@adres", DropDownList2.SelectedItem.Value);
                    cmd.Parameters.AddWithValue("@odeme_turu", odeme_sekli);
                    cmd.ExecuteNonQuery();
                    string mesaj_ = "Siparişiniz alındı. Sipariş durumuna profil>siparişler bölümünden erişebilirsiniz.";
                    Response.Write("<script>alert('" + mesaj_ + "');window.location = 'profil.aspx' ; </script>"); //works great

                }
            }
            else if (odeme_sekli == "online")
            {

                if (DropDownList1.SelectedValue != "0")
                {
                    using (SqlConnection con_2 = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                    {
                        con_2.Open();
                        SqlCommand cmd_2 = new SqlCommand("kupon_kullan", con_2);
                        cmd_2.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd_2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd_2.Parameters.AddWithValue("@kupon_id", Convert.ToInt64(DropDownList1.SelectedValue));
                        cmd_2.ExecuteNonQuery();
                        con_2.Close();
                        string mesaj_ = "Siparişiniz alındı. Sipariş durumuna profil>siparişler bölümünden erişebilirsiniz.";
                        Response.Write("<script>alert('" + mesaj_ + "');window.location = 'profil.aspx' ; </script>"); //works great
                    }
                }
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    con.Open();
                    SqlCommand cmd2 = new SqlCommand("select dbo.siparis_sayfasinda_kupon(@son_tutar,@kupon_id) as son_tutar", con);
                    cmd2.Parameters.AddWithValue("@son_tutar", Convert.ToDouble(siparis_tutar.InnerText.ToString()));
                    cmd2.Parameters.AddWithValue("@kupon_id", Convert.ToInt64(DropDownList1.SelectedValue));
                    SqlDataReader dr = cmd2.ExecuteReader();
                    if (dr.Read())
                    {
                        
                        SqlCommand cmd = new SqlCommand("siparis_ver_online", con);
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd.Parameters.AddWithValue("@mesaj", TextBox2.Text);
                        cmd.Parameters.AddWithValue("@adres", DropDownList2.SelectedItem.Value);
                        cmd.Parameters.AddWithValue("@odeme_turu", odeme_sekli);
                        cmd.Parameters.AddWithValue("@kart_sahibi", kart_sahibi.Text);
                        cmd.Parameters.AddWithValue("@kart_no", kart_no.Text);
                        cmd.Parameters.AddWithValue("@skt", skt.Text);
                        cmd.Parameters.AddWithValue("@cvv", cvv.Text);
                        cmd.Parameters.AddWithValue("@kart_kaydet", CheckBox1.Checked);
                        cmd.Parameters.AddWithValue("@son_tutar_", Convert.ToDouble(dr["son_tutar"]));
                        cmd.Parameters.AddWithValue("@kupon", Convert.ToInt64(DropDownList1.SelectedValue));
                        cmd.ExecuteNonQuery();
                        string mesaj_ = "Siparişiniz alındı. Sipariş durumuna profil>siparişler bölümünden erişebilirsiniz.";
                        Response.Write("<script>alert('" + mesaj_ + "');window.location = 'profil.aspx' ; </script>"); //works great
                    }
                }
                


            }
            
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            adres= DropDownList2.SelectedItem.Value;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            kupon = DropDownList1.SelectedItem.Text;
            if (DropDownList1.SelectedValue != "0")
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd2 = new SqlCommand("select dbo.siparis_sayfasinda_kupon(@son_tutar,@kupon_id) as son_tutar", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@son_tutar", Convert.ToDouble(siparis_tutar.InnerText.ToString()));
                    cmd2.Parameters.AddWithValue("@kupon_id", Convert.ToInt64(DropDownList1.SelectedValue));
                    SqlDataReader dr = cmd2.ExecuteReader();
                    if (dr.Read())
                    {
                        siparis_tutar.InnerText = dr["son_tutar"].ToString();
                        dr.Close();
                        con.Close();
                    }
                }
            }
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
             
        }
    }
}