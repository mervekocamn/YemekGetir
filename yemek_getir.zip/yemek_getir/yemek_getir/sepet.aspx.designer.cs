﻿//------------------------------------------------------------------------------
// <otomatik olarak oluşturulmuş>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler hatalı davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik olarak oluşturulmuş>
//------------------------------------------------------------------------------

namespace yemek_getir
{


    public partial class sepet
    {

        /// <summary>
        /// DataList1 denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DataList DataList1;

        /// <summary>
        /// son_tutar denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlGenericControl son_tutar;

        /// <summary>
        /// DataList2 denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DataList DataList2;

        /// <summary>
        /// LinkButton5 denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.LinkButton LinkButton5;
    }
}
