﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.DynamicData;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Net.Mime.MediaTypeNames;

namespace yemek_getir
{
    public partial class profil : System.Web.UI.Page
    {

        int id;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("select isim_soyisim, tel_no, dogum_tarihi from kullanici_bilgi where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        isim_soyisim.Text = dr["isim_soyisim"].ToString();
                        tel_no.Text = dr["tel_no"].ToString();

                        DateTime dt = Convert.ToDateTime(dr["dogum_tarihi"]);
                        this.dogum_tarihi.Text = dt.ToString("dd-MM-yyyy");

                        dr.Close();
                        con.Close();
                    }

                }
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("select * from kullanici_login where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        Label6.Text = dr["mail"].ToString();
                        dr.Close();
                        con.Close();
                    }
                    SqlCommand cmd2 = new SqlCommand("select * from adres where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    SqlDataAdapter da = new SqlDataAdapter(cmd2);

                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    DropDownList1.DataValueField = "adres";

                    DropDownList1.DataSource = dt;
                    DropDownList1.DataBind();


                }
                adres_duzenle.Text = DropDownList1.SelectedItem.Value;

                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("select * from favori_getir where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    DataList_favori.DataSource = cmd.ExecuteReader();
                    DataList_favori.DataBind();

                }
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("select * from onceki_siparisleri_goster where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi) and durum=@durum order by siparis_tarihi desc", con);
                    SqlCommand cmd2 = new SqlCommand("select * from onceki_siparisleri_goster where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi) and durum<>@durum  order by siparis_tarihi desc", con);                   
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.Parameters.AddWithValue("@durum", "teslim edildi");
                    cmd2.Parameters.AddWithValue("@durum", "teslim edildi");
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    DataList1.DataSource = cmd.ExecuteReader();
                    DataList1.DataBind();
                    DataList4.DataSource = cmd2.ExecuteReader();
                    DataList4.DataBind();
                    


                }

            }

        }

        protected void kaydet_kisisel(object sender, EventArgs e)
        {
            if(isim_soyisim.Text != string.Empty && tel_no.Text != string.Empty && dogum_tarihi.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("profil_guncelle", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.Parameters.AddWithValue("@isim", isim_soyisim.Text.ToString());
                    cmd.Parameters.AddWithValue("@telefon", tel_no.Text.ToString());
                    cmd.Parameters.AddWithValue("@dogum_tarihi", Convert.ToDateTime(dogum_tarihi.Text));
                    cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                    cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();

                    if (mesaj != " ")
                    {
                        string script2 = "alert(\"'" + mesaj + "'\");";
                        Response.Write("<script>alert('" + mesaj + "');window.location = 'profil.aspx' ; </script>");

                    }
                    con.Close();

                }
            }
            else
            {
                string script2 = "alert(\"'Boş alan bırakmayınız.'\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script2, true);
            }
            

        }
        protected void kaydet_hesap(object sender, EventArgs e)
        {
            if (sifre_eski.Text != string.Empty && sifre_yeni.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("hesap_guncelle", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.Parameters.AddWithValue("@eski_sifre", sifre_eski.Text.ToString());
                    cmd.Parameters.AddWithValue("@yeni_sifre", sifre_yeni.Text.ToString());
                    cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                    cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();

                    if (mesaj != " ")
                    {
                        string script2 = "alert(\"'" + mesaj + "'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);

                    }
                    con.Close();

                }
            }
            else
            {
                string script2 = "alert(\"'Boş alan bırakmayınız.'\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script2, true);
            }
        }
        protected void hesap_sil(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
            {
                SqlCommand cmd = new SqlCommand("kullanici_sil_proc", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                cmd.ExecuteNonQuery();
                con.Close();
                Session.Remove("kullanici_adi");
                string mesaj = "Hesap silme işleminiz başarıyla gerçekleşti.";
                string script2 = "alert(\"'" + mesaj + "'\");";
                Response.Write("<script>alert('" + mesaj + "');window.location = 'ana_sayfa.aspx' ; </script>");
            }
        }
        protected void kaydet_adres(object sender, EventArgs e)
        {
            if(adres_duzenle.Text!=string.Empty)
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("adres_duzenle", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.Parameters.AddWithValue("@eski_adres", DropDownList1.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@yeni_adres", adres_duzenle.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();


                }
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {

                    SqlCommand cmd2 = new SqlCommand("select * from adres where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    SqlDataAdapter da = new SqlDataAdapter(cmd2);

                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    DropDownList1.DataValueField = "adres";

                    DropDownList1.DataSource = dt;
                    DropDownList1.DataBind();


                }
                adres_duzenle.Text = DropDownList1.SelectedItem.Value;
            }
            else
            {
                string script2 = "alert(\"'Lütfen adresinizi giriniz.'\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script2, true);
            }
            
        }
        protected void ekle_adres(object sender, EventArgs e)
        {
            if(adres_ekle.Text!=string.Empty)
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("addres_ekle", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.Parameters.AddWithValue("@adres", adres_ekle.Text);
                    cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                    cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();
                    string mesaj2 = "Adres başarıyla eklendi";
                    if (mesaj != " ")
                    {

                        string script2 = "alert(\"'" + mesaj + "'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);

                    }
                    else
                    {
                        string script2 = "alert(\"'" + mesaj2 + "'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);
                    }
                    con.Close();
                    adres_ekle.Text = " ";

                }
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {

                    SqlCommand cmd2 = new SqlCommand("select * from adres where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    SqlDataAdapter da = new SqlDataAdapter(cmd2);

                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    DropDownList1.DataValueField = "adres";

                    DropDownList1.DataSource = dt;
                    DropDownList1.DataBind();


                }
                adres_duzenle.Text = DropDownList1.SelectedItem.Value;
            }
            else
            {
                string script2 = "alert(\"'Lütfen adresinizi giriniz.'\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script2, true);
            }
            
        }
    

        protected void DataList2_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "sepete_ekle")
            {
                id = Convert.ToInt32(e.CommandArgument);
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    if (Session["kullanici_adi"] != null)
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("sepete_ekle", con);
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd.Parameters.AddWithValue("@id", id);

                        cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                        cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();
                        string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();

                        if (mesaj != " ")
                        {
                            string script2 = "alert(\"'" + mesaj + "'\");";
                            ScriptManager.RegisterStartupScript(this, GetType(),
                                                  "ServerControlScript", script2, true);

                        }
                        else
                        {

                            Response.Redirect("sepet.aspx");
                        }
                    }
                    else
                    {
                        string script2 = "alert(\"'Lütfen alışverişten önce hesabınıza giriş yapınız.'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);
                    }


                }
            }
            if (e.CommandName == "favori_ekle")
            {
                id = Convert.ToInt32(e.CommandArgument);
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    if (Session["kullanici_adi"] != null)
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("favori_ekle", con);
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@urun_id", id);
                        cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                        cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                        cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();
                        string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();
                        using (SqlConnection con_ = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                        {
                            SqlCommand cmd_ = new SqlCommand("select * from favori_getir where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi)", con_);
                            con_.Open();
                            cmd_.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                            DataList_favori.DataSource = cmd_.ExecuteReader();
                            DataList_favori.DataBind();

                        }
                        string script2 = "alert(\"'" + mesaj + "'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);

                    }
                    else
                    {
                        string script2 = "alert(\"'Lütfen önce hesabınıza giriş yapınız.'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);
                    }


                }
            }

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            adres_duzenle.Text = DropDownList1.SelectedItem.Value;
        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            
            if (e.CommandName == "detay_goster")
            {
                int index = e.Item.ItemIndex;
                DataList1.Items[index].FindControl("detay_tablosu").Visible=true;
                DataList1.Items[index].FindControl("LinkButton4").Visible = false;
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd3 = new SqlCommand("select * from detay_siparis where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi) and durum=@durum and id=@id", con);
                    con.Open();
                    cmd3.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd3.Parameters.AddWithValue("@durum", "teslim edildi");
                    cmd3.Parameters.AddWithValue("@id", e.CommandArgument.ToString());
                    DataList dl3 = DataList1.Items[index].FindControl("detay_tablosu").FindControl("DataList3") as DataList;
                    dl3.DataSource = cmd3.ExecuteReader();
                    dl3.DataBind();
                }
                

            }
           else if (e.CommandName == "detay_gizle")
            {
                int index = e.Item.ItemIndex;
                DataList1.Items[index].FindControl("detay_tablosu").Visible = false;
                DataList1.Items[index].FindControl("LinkButton4").Visible = true;
            }
           else if(e.CommandName == "yorum_yap")
            {
                int index = e.Item.ItemIndex;
                
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd3 = new SqlCommand("select dbo.yorum_var_mi(@kullanici_adi,@siparis_id) as sonuc", con);
                    con.Open();
                    cmd3.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd3.Parameters.AddWithValue("@siparis_id", e.CommandArgument.ToString());
                    SqlDataReader dr = cmd3.ExecuteReader();
                    if (dr.Read())
                    {
                        if (Convert.ToBoolean(dr["sonuc"]) ==true )
                        {
                            string script2 = "alert(\"'Bu sipariş için yorumunuz ve puanınız var.'\");";
                            ScriptManager.RegisterStartupScript(this, GetType(),
                                                  "ServerControlScript", script2, true);
                        }
                        else 
                        {
                            DataList1.Items[index].FindControl("yorum_tablosu").Visible = true;
                            DataList1.Items[index].FindControl("LinkButton3").Visible = false;
                        }

                        dr.Close();
                        con.Close();
                    }
                }

            }
            else if (e.CommandName == "yorum_gonder")
            {
                int index = e.Item.ItemIndex;
                DataList1.Items[index].FindControl("yorum_tablosu").Visible = false;
                DataList1.Items[index].FindControl("LinkButton3").Visible = true;
                TextBox yorum = (TextBox)DataList1.Items[index].FindControl("TextBox1");
                RadioButtonList RB = (RadioButtonList)DataList1.Items[index].FindControl("yorum_puan");
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd = new SqlCommand("yorum_kaydet", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd.Parameters.AddWithValue("@siparis_id", e.CommandArgument.ToString());
                    cmd.Parameters.AddWithValue("@yorum_metni", yorum.Text);
                    cmd.Parameters.AddWithValue("@puan", Convert.ToInt32(RB.SelectedValue));
                    cmd.Parameters.Add("@mesaj", SqlDbType.NVarChar, 150);
                    cmd.Parameters["@mesaj"].Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    string mesaj = (cmd.Parameters["@mesaj"].Value).ToString();

                    if (mesaj != " ")
                    {
                        string script2 = "alert(\"'" + mesaj + "'\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script2, true);

                    }
                    else
                    {
                        Response.Redirect("profil.aspx");
                    }
                }
            }
            else if (e.CommandName == "yorum_iptal")
            {
                int index = e.Item.ItemIndex;
                DataList1.Items[index].FindControl("yorum_tablosu").Visible = false;
                DataList1.Items[index].FindControl("LinkButton3").Visible = true;
            }
        }

        protected void DataList4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DataList4_ItemCommand(object source, DataListCommandEventArgs e)
        {
            
            if (e.CommandName == "detay_goster_2")
            {
                int index = e.Item.ItemIndex;
                DataList4.Items[index].FindControl("detay_tablosu_2").Visible = true;
                DataList4.Items[index].FindControl("LinkButton4_2").Visible = false;
                
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-N599T4N\\SQLEXPRESS;Initial Catalog=YemekGetir;Integrated Security=True; MultipleActiveResultSets=True"))
                {
                    SqlCommand cmd3 = new SqlCommand("select * from detay_siparis where kullanici_id= dbo.kullanici_id_getir(@kullanici_adi) and durum<>@durum and id=@id", con);
                    con.Open();
                    cmd3.Parameters.AddWithValue("@kullanici_adi", Session["kullanici_adi"]);
                    cmd3.Parameters.AddWithValue("@durum", "teslim edildi");
                    cmd3.Parameters.AddWithValue("@id", e.CommandArgument.ToString());
                    DataList dl6 = DataList4.Items[index].FindControl("detay_tablosu_2").FindControl("DataList6") as DataList;
                    dl6.DataSource = cmd3.ExecuteReader();
                    dl6.DataBind();
                }



            }
            else if (e.CommandName == "detay_gizle_2")
            {
                int index = e.Item.ItemIndex;
                DataList4.Items[index].FindControl("detay_tablosu_2").Visible = false;
                DataList4.Items[index].FindControl("LinkButton4_2").Visible = true;
            }
        }
    }


}
